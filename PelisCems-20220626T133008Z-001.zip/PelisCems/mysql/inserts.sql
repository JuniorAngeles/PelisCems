-- insert
insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('THE BATMAN', 'Pelicula de accion Ben Aflex', 'https://i.imgur.com/61emmRt.jpg', 'https://www.mediafire.com/file/6lbusra8ngpm8po/BatMan_2022.mp4/file');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Un espía y medio', 'La roca accion', 'https://i.imgur.com/1hsQcdk.jpg', 'https://mega.nz/file/hwwXAJ6Q#wp-xQNj8W_z_sVMFf_qbPMV6ClXIH0CRj13iqSqToLg');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('13 Horas', 'Accion', 'https://i.imgur.com/HQ9Fl9O.jpg', 'https://mega.nz/file/EUUnHLCa#eUkpirTTK17MSdVb8XMQmIHvDrdVfa_uUoBD1vjDUuw');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Geminis Man', 'Accion Wili Smit', 'https://i.imgur.com/6AVgkPu.png', 'https://www.mediafire.com/file/bp7c4p23umy5p9c/Geminis.mp4/file');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Halo', 'Serie-Accion', 'https://i1.wp.com/peliserieshd.com/wp-content/uploads/2022/04/halo-peliserieshd.com_.jpg?w=950&ssl=1', 'file:///home/edward/Escritorio/PelisCems/website/lugar-Descargar%20Serie.html');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Truth Seekers', 'Truth Seekers-comedia', 'https://pics.filmaffinity.com/Truth_Seekers_Serie_de_TV-325974442-large.jpg', 'file:///home/edward/Escritorio/PelisCems/website/Descargar-Serie%20Truth%20Seekers.html');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Insania', 'Insania-Terror', 'https://pics.filmaffinity.com/Ins_nia_Serie_de_TV-462740748-large.jpg', 'file:///home/edward/Escritorio/PelisCems/website/inside-lugar%20de%20descarga.html');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Black Summer', 'Black Summer-Terror', 'https://pics.filmaffinity.com/Black_Summer_Serie_de_TV-920592550-large.jpg', 'file:///home/edward/Escritorio/PelisCems/website/Black%20Summer-Descargar%20capituls.html');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Son como niños 2', '', 'https://i.imgur.com/WhMiJo5.jpg', '#');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Pequeño pero peligroso', '', 'https://i.imgur.com/8iYRt1P.jpg', '#');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('a mi altura', '', 'https://i.imgur.com/zDytWSo.png', '#');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Alguien como el', '', 'https://i.imgur.com/ig3HrgR.jpg', '#');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Cuando te encuentre', '', 'https://i.imgur.com/5S9IESS.jpg', '#');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Downton Abbey 2 Una nueva era', '', 'https://i.imgur.com/0jh8u4S.jpg', '#');

insert into peliculas (titulo, descripcionBusqueda, imagenUrl, descargarUrl) values ('Navidad en California', '', 'https://i.imgur.com/LRJ08jB.jpg', '#');

